echo "Installing Heroku Toolbelt..."
wget -qO- https://toolbelt.heroku.com/install-ubuntu.sh | sh

