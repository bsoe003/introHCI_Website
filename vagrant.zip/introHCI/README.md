Vagrant for Introduction to HCI
=====

Includes setup files to create an Ubuntu (Precise Pangolin) machine.

Prerequisites
----
VirtualBox and Vagrant

Installation
----
Clone or unzip the repository. Run ```vagrant up``` from the command line.
